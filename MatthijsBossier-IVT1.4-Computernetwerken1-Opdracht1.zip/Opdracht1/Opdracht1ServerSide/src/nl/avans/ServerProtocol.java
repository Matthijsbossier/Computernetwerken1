package nl.avans;

import com.google.gson.Gson;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.net.MalformedURLException;
import java.net.URL;

/**
 * Created by Matthijs on 22-5-2017.
 */
public class ServerProtocol {
        private static final int WAITING = 0;
        private static final int SENTBOOKINFO = 1;

        private int state = WAITING;


        public String processInput(String theInput) throws IOException {
            String theOutput = null;

            if (state == WAITING) {
                theOutput = "Voer een isbn in a.u.b.";
                state = SENTBOOKINFO;
            } else if (state == SENTBOOKINFO) {

                URL bookInfo = new URL("https://www.googleapis.com/books/v1/volumes?q=isbn:" + theInput);

                InputStream input = bookInfo.openStream();
                Reader reader = new InputStreamReader(input, "UTF-8");
                JsonResult result = new Gson().fromJson(reader, JsonResult.class);

                theOutput = "Titel: " + result.getBookDetail().getTitle() + ", Subtitel: " + result.getBookDetail().getSubTitle() + ", Auteurs:" + result.getBookDetail().getAuthors();

            } else {
                    theOutput = "Voer een geldig isbn in.";
                }

            return theOutput;
        }

}
